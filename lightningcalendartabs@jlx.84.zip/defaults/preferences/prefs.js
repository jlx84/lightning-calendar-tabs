pref("extensions.lightningcalendartabs.tabs.months.enabled", true);
pref("extensions.lightningcalendartabs.tabs.months.future", 6);
pref("extensions.lightningcalendartabs.tabs.months.past", 3);

pref("extensions.lightningcalendartabs.tabs.multiweeks.enabled", true);
pref("extensions.lightningcalendartabs.tabs.multiweeks.future", 2);
pref("extensions.lightningcalendartabs.tabs.multiweeks.past", 1);

pref("extensions.lightningcalendartabs.tabs.weeks.enabled", true);
pref("extensions.lightningcalendartabs.tabs.weeks.future", 2);
pref("extensions.lightningcalendartabs.tabs.weeks.past", 1);

pref("extensions.lightningcalendartabs.tabs.days.enabled", true);
pref("extensions.lightningcalendartabs.tabs.days.future", 7);
pref("extensions.lightningcalendartabs.tabs.days.past", 2);

pref("extensions.lightningcalendartabs.tabs.text_color_current", "#000000");
pref("extensions.lightningcalendartabs.tabs.text_color_past", "#666666");
pref("extensions.lightningcalendartabs.tabs.text_color_future", "#000000");

pref("extensions.lightningcalendartabs.tabs.text_color_new_period", "#000000");
